//
//  sjbDStatusViewController.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sjbObject.h"

@interface sjbDStatusViewController: UITableViewController <UITableViewDataSource, UITableViewDelegate>{
    NSMutableArray *objects;
    sjbObject *selectedObject;
}
@property (nonatomic, strong) NSMutableArray *objects;
@property (nonatomic, strong) sjbObject *selectedObject;
- (IBAction)refresh:(id)sender;
@end
