//
//  sjbObject.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <KinveyKit/KinveyKit.h>

@interface sjbObject : NSObject <KCSPersistable>{
    NSNumber *userId;
    NSString *deviceId;
    NSString *status;
    NSNumber *estTime;
}

@property (nonatomic, strong) NSString *entityId;
@property (nonatomic, strong) NSNumber *userId;
@property (nonatomic, strong) NSString *deviceId;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSNumber *estTime;

-(id)initWithData:(NSNumber *) u theDeviceId:(NSString *) d theStatus:(NSString *) s theEstTime:(NSNumber *) t;


@end
