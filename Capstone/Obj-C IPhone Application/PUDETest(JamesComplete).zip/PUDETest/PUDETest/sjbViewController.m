//
//  sjbViewController.m
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import "sjbViewController.h"

@interface sjbViewController ()

@end

@implementation sjbViewController
@synthesize btnAbout,btnDevice;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)unwindToThisViewController:(UIStoryboardSegue *)segue
{
    
}

@end
