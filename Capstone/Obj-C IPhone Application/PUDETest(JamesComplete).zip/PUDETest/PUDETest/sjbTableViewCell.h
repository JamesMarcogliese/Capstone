//
//  sjbTableViewCell.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-30.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sjbTableViewCell : UITableViewCell{
    UILabel *primaryLabel;
    UILabel *secondaryLabel;
}

@property (nonatomic, strong) UILabel *primaryLabel;
@property (nonatomic, strong) UILabel *secondaryLabel;

@end
