//
//  sjbDStatusViewController2.m
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-30.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import "sjbDStatusViewController2.h"
#import "sjbAppDelegate.h"

@interface sjbDStatusViewController2 ()

@end

@implementation sjbDStatusViewController2
@synthesize device,user,status,time,timer,extraLabel,userLabel,userText,deviceText,statusText;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *stringNum = [NSString stringWithFormat:@"%@",userText];
    //Fills labels with info taken from the previous view
    user.text = stringNum;
    device.text = deviceText;
    status.text = statusText;
    [self updateTimer];
    if ([statusText  isEqual: @"Complete"]){
        timer.hidden = YES;
        extraLabel.hidden = YES;
    }  
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//-(IBAction)refreshButton:(id)sender
//{
//    [self refresh];
//}

-(void)updateTimer
{
    //Display time remaining on encryption. Time required to commplete is taken from Kinvey backend and added to the current time to show the user how much
    NSDate *today = [[NSDate alloc] init];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *offsetComponents = [[NSDateComponents alloc] init];
    [offsetComponents setMinute:time];
    NSDate *endTime = [gregorian dateByAddingComponents:offsetComponents toDate:today options:0];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm:ss"];
    NSString *getTime = [dateFormatter stringFromDate:endTime];
    timer.text = getTime;
}

//-(void)refresh
//{
//    extraLabel.hidden = NO;
//    userLabel.hidden = NO;
//    sjbAppDelegate *mainDelegate = (sjbAppDelegate *)[[UIApplication sharedApplication] delegate];
//    
//    sjbObject *object = [mainDelegate object];
//    device.text = object.deviceId;
//    NSNumber *num = object.userId;
//    //NSLog(@"%d",num);
//    NSString *string = [NSString stringWithFormat:@"%@",num];
//    user.text = string;
//    if([object.status  isEqual: @"Complete"])
//    {
//        extraLabel.hidden = YES;
//        timer.hidden = YES;
//    }
//    else
//    {
//        extraLabel.hidden = NO;
//        timer.hidden = NO;
//        [self updateTimer];
//    }
//    status.text = object.status;
//    time.text = object.estTime;
//    
//}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
