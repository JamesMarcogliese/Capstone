//
//  sjbDStatusViewController2.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-30.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sjbDStatusViewController2 : UIViewController
{
    IBOutlet UILabel *user;
    IBOutlet UILabel *device;
    IBOutlet UILabel *status;
    NSNumber *time;
    IBOutlet UILabel *timer;
    IBOutlet UILabel *extraLabel;
    IBOutlet UILabel *userLabel;
    NSNumber *userText;
    NSString *deviceText;
    NSString *statusText;
    //NSTimer *timer;
}

@property (nonatomic, strong) IBOutlet UILabel *user;
@property (nonatomic, strong) IBOutlet UILabel *device;
@property (nonatomic, strong) IBOutlet UILabel *status;
@property (nonatomic, strong) NSNumber *time;
@property (nonatomic, strong) IBOutlet UILabel *timer;
@property (nonatomic, strong) IBOutlet UILabel *extraLabel;
@property (nonatomic, strong) IBOutlet UILabel *userLabel;
@property (nonatomic, strong) NSNumber *userText;
@property (nonatomic, strong) NSString *deviceText;
@property (nonatomic, strong) NSString *statusText;
//-(IBAction)refreshButton:(id)sender;
-(void)updateTimer;

@end
