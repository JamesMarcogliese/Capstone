//
//  sjbViewController.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface sjbViewController : UIViewController{
    
    IBOutlet UIButton *btnDevice;
    IBOutlet UIButton *btnAbout;
    
}
@property (strong, nonatomic) IBOutlet UIButton *btnDevice;
@property (strong, nonatomic) IBOutlet UIButton *btnAbout;

@end
