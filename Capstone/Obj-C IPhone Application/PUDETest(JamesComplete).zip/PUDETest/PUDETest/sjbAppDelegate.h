//
//  sjbAppDelegate.h
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sjbObject.h"

@interface sjbAppDelegate : UIResponder <UIApplicationDelegate>{
    NSString *user;
    NSString *device;
    NSString *status;
    NSString *time;
    NSMutableArray *deviceArray;
    sjbObject *object;
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSString *user;
@property (strong, nonatomic) NSString *device;
@property (strong, nonatomic) NSString *time;
@property (strong, nonatomic) NSString *status;
@property (strong, nonatomic) NSMutableArray *deviceArray;
@property (strong, nonatomic) sjbObject *object;

-(void)refresh;

@end
