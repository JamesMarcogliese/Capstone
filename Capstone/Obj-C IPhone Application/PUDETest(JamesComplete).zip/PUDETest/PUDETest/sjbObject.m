//
//  sjbObject.m
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import "sjbObject.h"

@implementation sjbObject
@synthesize entityId,userId,deviceId,status,estTime;

-(id)initWithData:(NSNumber *) u theDeviceId:(NSString *) d theStatus:(NSString *) s theEstTime:(NSNumber *) t
{
    if(self = [self init])
    {
        [self setUserId:u];
        [self setDeviceId:d];
        [self setStatus:s];
        [self setEstTime:t];
    }
    return self;
    
}

- (NSDictionary *) hostToKinveyPropertyMapping {
    static NSDictionary* mapping;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        mapping = @{@"entityID": @"entityID",
                    @"deviceId": @"deviceId",
                    @"status": @"status",
                    @"estTime": @"estTime",
                    @"userId": @"userId",
                    };
    });
    return mapping;
}

@end
