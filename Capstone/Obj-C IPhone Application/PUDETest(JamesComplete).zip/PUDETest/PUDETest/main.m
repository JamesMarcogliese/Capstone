//
//  main.m
//  PUDETest
//
//  Created by xcode on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "sjbAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([sjbAppDelegate class]));
    }
}
