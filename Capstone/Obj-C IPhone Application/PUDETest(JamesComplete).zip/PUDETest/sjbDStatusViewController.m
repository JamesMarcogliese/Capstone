//
//  sjbDStatusViewController.m
//  PUDETest
//
//  Created by James Marcogliese on 2014-11-29.
//  Copyright (c) 2014 xcode. All rights reserved.
//

#import "sjbDStatusViewController.h"
#import "sjbDStatusViewController2.h"
#import "sjbObject.h"
#import "sjbAppDelegate.h"
#import "sjbTableViewCell.h"

//@interface sjbDStatusViewController ()
//@end

@implementation sjbDStatusViewController
@synthesize objects,selectedObject;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    sjbAppDelegate *mainDelegate = (sjbAppDelegate *)[[UIApplication sharedApplication] delegate];
    
    return [mainDelegate.deviceArray count];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(IBAction)refresh:(id)sender
{
    //insert grab delegate
}

-(IBAction)unwindToThisViewControllerDevice:(UIStoryboardSegue *)segue
{
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Sets up TableView
    static NSString *CellIdentifier = @"Cell";
    sjbTableViewCell *cell = (sjbTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        cell = [[sjbTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    sjbAppDelegate *mainDelegate = (sjbAppDelegate *)[[UIApplication sharedApplication] delegate];
    //Fills row with device name
    NSUInteger row = [indexPath row];
    sjbObject *data = [mainDelegate.deviceArray objectAtIndex:row];
    NSString *string = @"Device: ";
    NSString *string2 = [string stringByAppendingString:data.deviceId];
    cell.primaryLabel.text = string2;
    cell.secondaryLabel.text = @" ";
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Selects the row that was picked and launches the segue to the details View Controller
    NSInteger row = indexPath.row;
    sjbAppDelegate *mainDelegate = (sjbAppDelegate *)[[UIApplication sharedApplication] delegate];
    self.selectedObject = [mainDelegate.deviceArray objectAtIndex:row];
    [self performSegueWithIdentifier:@"detailSegue" sender:self];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"detailSegue"])
    {
        //Data to pass to viewController
        sjbDStatusViewController2 *vc = [segue destinationViewController];
        vc.userText = selectedObject.userId;
        vc.deviceText = selectedObject.deviceId;
        vc.statusText = selectedObject.status;
        vc.time = selectedObject.estTime;
    }
}


@end

